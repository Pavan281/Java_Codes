import java.awt.*;
import java.awt.event.*;

class MF4 extends Frame implements ActionListener
{
	TextField t1,t2,t3;
	Button b;
	Label l1,l2;	
	MF4()
	{
		setSize(600,500);
		setLayout(new FlowLayout());
		l1=new Label("Enter Number : ");
		l2=new Label("Result");
		t1=new TextField(10);
		t2=new TextField(10);
		t3=new TextField(10);
		b=new Button("CHECK/VERIFY");

		add(l1);
		add(t1);
		add(t2);
		add(b);
		add(l2);
		add(t3);
		b.addActionListener(this);
		setVisible(true);
	}

	public static void main(String a[])
	{
		new MF4();
	}

	public void actionPerformed(ActionEvent e)
	{
		int a=Integer.parseInt(t1.getText());
		int b=Integer.parseInt(t2.getText());
		if(a>b)
			t3.setText("a is BIG");
		else
			t3.setText("b is BIG"); 
	}
}