import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class MyData2 extends JFrame implements ActionListener
{
	Connection con;
	Statement st;
	ResultSet rs;

	JTextField num,nam,sal;
	JLabel lnum,lnam,lsal;
	JButton fst,nxt,pre,lst,ne,mo,de,xi;
	GridBagConstraints gc;
	public MyData2()
	{
		setSize(500,400);
		setLocation(400,300);
		setLayout(new GridBagLayout());
		gc=new GridBagConstraints();

		lnum=new JLabel("Emp. Id.");
		lnam=new JLabel("Emp. Name");
		lsal=new JLabel("Emp. Salary");
		num=new JTextField(10);
		nam=new JTextField(10);
		sal=new JTextField(10);

		fst=new JButton("First");
		nxt=new JButton("Next");
		pre=new JButton("Previous");
		lst=new JButton("Last");
		ne=new JButton("New");
		mo=new JButton("Modify");
		de=new JButton("Delete");
		xi=new JButton("Exit");


		lnum.setForeground(Color.blue); 
		lnam.setForeground(Color.blue); 
		lsal.setForeground(Color.blue); 
		num.setForeground(Color.blue);
		nam.setForeground(Color.blue);
		sal.setForeground(Color.blue); 
		fst.setForeground(Color.blue);
		nxt.setForeground(Color.blue);
		pre.setForeground(Color.blue);
		lst.setForeground(Color.blue); 
		ne.setForeground(Color.blue); 
		mo.setForeground(Color.blue); 
		de.setForeground(Color.blue); 
		xi.setForeground(Color.blue); 


		lnum.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		lnam.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		lsal.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		num.setFont(new Font("comic sans ms",Font.PLAIN,26));
		nam.setFont(new Font("comic sans ms",Font.PLAIN,26));
		sal.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		fst.setFont(new Font("comic sans ms",Font.PLAIN,26));
		nxt.setFont(new Font("comic sans ms",Font.PLAIN,26));
		pre.setFont(new Font("comic sans ms",Font.PLAIN,26));
		lst.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		ne.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		mo.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		de.setFont(new Font("comic sans ms",Font.PLAIN,26)); 
		xi.setFont(new Font("comic sans ms",Font.PLAIN,26)); 



		addC(lnum,1,1,2,1);
		addC(num,1,3,2,1);
		addC(lnam,2,1,2,1);
		addC(nam,2,3,2,1);
		addC(lsal,3,1,2,1);
		addC(sal,3,3,2,1);

		addC(fst,4,1,1,1);
		addC(nxt,4,2,1,1);
		addC(pre,4,3,1,1);
		addC(lst,4,4,1,1);
		addC(ne,5,1,1,1);
		addC(mo,5,2,1,1);
		addC(de,5,3,1,1);
		addC(xi,5,4,1,1);

		fst.addActionListener(this);		
		nxt.addActionListener(this);
		pre.addActionListener(this);
		lst.addActionListener(this);
		ne.addActionListener(this);
		mo.addActionListener(this);
		de.addActionListener(this);
		xi.addActionListener(this);

		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "rajani");

		st=con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		rs=st.executeQuery("select * from emp");
		}catch(Exception e)
		{
	JOptionPane.showMessageDialog(null,"Conenction NOT extablished", "ERROR", JOptionPane.ERROR_MESSAGE);
		}

		setVisible(true);
	}

	public void addC(Component cc, int r, int c, int w, int h)
	{
		gc.gridx=c;
		gc.gridy=r;
		gc.gridwidth=w;
		gc.gridheight=h;
		gc.fill=gc.BOTH;
		add(cc,gc);
	}
	public static void main(String a[])
	{
		new MyData2();
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==nxt)
		{
			try{
			rs.next();
			num.setText( Integer.toString(rs.getInt(1)) );
			nam.setText(rs.getString(2));
			sal.setText( Integer.toString(rs.getInt(3)) );
			}catch(Exception ee)
			{
	JOptionPane.showMessageDialog(null,"NO MORE DATA FOUND","information", JOptionPane.INFORMATION_MESSAGE);
			}
		}

		if(e.getSource()==pre)
		{
			try{
			rs.previous();
			num.setText( Integer.toString(rs.getInt(1)) );
			nam.setText(rs.getString(2));
			sal.setText( Integer.toString(rs.getInt(3)) );
			}catch(Exception ee)
			{
		
	JOptionPane.showMessageDialog(null,"NO MORE DATA FOUND","information", JOptionPane.INFORMATION_MESSAGE);
			}
		}

		if(e.getSource()==xi)
		{
	if( JOptionPane.showConfirmDialog(null,"Do you wish to close?", "confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
		System.exit(0);
		}
	}
}