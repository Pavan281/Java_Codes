import java.awt.*;
import java.awt.event.*;

class MF1 extends Frame implements ActionListener
{
	TextField t1,t2,t3;
	Button b;
	Label l1,l2;	
	MF1()
	{
		setSize(600,500);
		setLayout(new FlowLayout());
		l1=new Label("Enter 2 numbers");
		l2=new Label("Result");
		t1=new TextField(10);
		t2=new TextField(10);
		t3=new TextField(10);
		b=new Button("ADD");

		add(l1);
		add(t1);
		add(t2);
		add(b);
		add(l2);
		add(t3);
		b.addActionListener(this);
		setVisible(true);
	}

	public static void main(String a[])
	{
		new MF1();
	}

	public void actionPerformed(ActionEvent e)
	{
		int a= Integer.parseInt( t1.getText() );
		int b= Integer.parseInt( t2.getText() );
		int c=a+b;
		t3.setText( Integer.toString(c) );
	}
}