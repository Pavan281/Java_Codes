import java.awt.*;
class C
{
	public static void main(String a[])
	{
		Frame f;
		Label l1,l2,l3,l4,l5,l6,l7,l8;
		TextField t1,t2,t3,t4,t5,t6,t7,t8;
		Button b1,b2;
	
		f = new Frame();
		l1 = new Label("STUDENT NAME");
		l2 = new Label("HALL TICKET NUMBER");
		l3 = new Label("TELUGU");
		l4 = new Label("HINDI");
		l5 = new Label("ENGLISH");
		l6 = new Label("MATHEMATICS");
		l7 = new Label("SCIENCE");		
		l8 = new Label("SOCIAL STUDIES");
		t1 = new TextField(10);
		t2 = new TextField(10);
		t3 = new TextField(10);
		t4 = new TextField(10);
		t5 = new TextField(10);
		t6 = new TextField(10);
		t7 = new TextField(10);
		t8 = new TextField(10);
		b1 = new Button("SAVE");
		b2 = new Button("CLOSE");
		
		f.setSize(400,300);
		f.setLayout(new FlowLayout());
		f.add(l1);
		f.add(t1);
		f.add(l2);
		f.add(t2);
		f.add(l3);
		f.add(t3);
		f.add(l4);
		f.add(t4);
		f.add(l5);
		f.add(t5);
		f.add(l6);
		f.add(t6);
		f.add(l7);
		f.add(t7);
		f.add(l8);
		f.add(t8);
		f.add(b1);
		f.add(b2);
		f.setVisible(true);
	}
}