import java.awt.*;
import java.awt.event.*;
class ATM extends Frame implements ItemListener
{
	Choice its,qut;
	List pro,pri,spro,spri,squt,stot;
	TextField gt;
	ATM()
	{
		setSize(800,300);		

		setLocation(300,300);	
		setLayout(new FlowLayout());
		its=new Choice();
		qut=new Choice();
		pro=new List();
		pri=new List();
		spro=new List();
		spri=new List();
		squt=new List();		
		stot=new List();
		gt=new TextField("0",10);
		its.add("soaps");
		its.add("pastes");
		for(int i=0;i<21;i++)
			qut.add(Integer.toString(i));
		add(new Label("items"));
		add(its);		
		add(new Label("products"));
		add(pro);
		add(new Label("prices"));
		add(pri);
		add(new Label("quantity"));
		add(qut);
		add(new Label("sel.products"));
		add(spro);
		add(new Label("sel.prices"));		
		add(spri);
		add(new Label("sel.quantity"));
		add(squt);
		add(new Label("sel.total"));
		add(stot);
		add(new Label("Grand Total"));
		add(gt);
		pri.setEnabled(false);
		spro.setEnabled(false);
		spri.setEnabled(false);
		squt.setEnabled(false);
		stot.setEnabled(false);
		gt.setEditable(false);	
		its.addItemListener(this);
		pro.addItemListener(this);
		qut.addItemListener(this);
		setVisible(true);
	
	}	
	public static void main(String a[])
	{
		new ATM();
	}
	public void itemStateChanged(ItemEvent e)
	{
		if(e.getSource()==its)
		{
			pro.removeAll();
			pri.removeAll();
			if(its.getSelectedItem().equals("soaps"))
			{	pro.add("lux");pri.add("17");
				pro.add("rexona");pri.add("37");
				pro.add("lifboy");pri.add("27");
				pro.add("cinthol");pri.add("47");
			}
			if(its.getSelectedItem().equals("pastes"))
			{	pro.add("colgate");pri.add("170");
				pro.add("sensodyne");pri.add("237");
				pro.add("closeup");pri.add("207");
				pro.add("dabur red");pri.add("247");
			}
		}
		if(e.getSource()==pro)
		{
			pri.select(pro.getSelectedIndex());
		}
		if(e.getSource()==qut)
		{
			spro.add(pro.getSelectedItem());
			spri.add(pri.getSelectedItem());
			squt.add(qut.getSelectedItem());
			int a=Integer.parseInt(pri.getSelectedItem());
			int b=Integer.parseInt(qut.getSelectedItem());
			int c=a*b;
			stot.add(Integer.toString(c));
			int x=Integer.parseInt(gt.getText());
			int y=x+c;
			gt.setText(Integer.toString(y));
		}
		
	}
}