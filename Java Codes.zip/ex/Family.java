class Father
{
	public static void main(String p[])
	{
		System.out.println("Fathername : P.JAGADEESH");
	}
}
class Mother
{
	public static void main(String p[])
	{
		System.out.println("Mothername : P.Sarala");
	}
}
class Brother
{
	public static void main(String p[])
	{
		System.out.println("Brothername : P.Thanmai Srinivas");
	}
}
class Sister
{
	public static void main(String p[])
	{
		System.out.println("Sistername : P.Kiranmaie");
	}
}