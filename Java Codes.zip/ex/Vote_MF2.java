import java.awt.*;
import java.awt.event.*;

class MF2 extends Frame implements ActionListener
{
	TextField t1,t2,t3;
	Button b;
	Label l1,l2;	
	MF2()
	{
		setSize(600,500);
		setLayout(new FlowLayout());
		l1=new Label("Enter Person Name : ");
		l2=new Label("Result");
		t1=new TextField(10);
		t2=new TextField(10);
		t3=new TextField(10);
		b=new Button("CHECK/VERIFY");

		add(l1);
		add(t1);
		add(new Label("Enter Age : "));
		add(t2);
		add(b);
		add(l2);
		add(t3);
		b.addActionListener(this);
		setVisible(true);
	}

	public static void main(String a[])
	{
		new MF2();
	}

	public void actionPerformed(ActionEvent e)
	{
		int a=Integer.parseInt(t2.getText());
		if(a>18)
			t3.setText("ELIGIBLE for Voting");
		else
			t3.setText("NOT ELIGIBLE for Voting"); 
	}
}