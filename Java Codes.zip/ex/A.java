class A
{
	public static void main(String p[])
	{
		System.out.println("A");
	}
}