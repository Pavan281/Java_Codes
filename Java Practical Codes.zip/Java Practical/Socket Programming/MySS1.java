import java.net.*;
import java.io.*;

class MySS1
{
	public static void main(String a[]) throws Exception
	{
		ServerSocket ss=new ServerSocket(12325);
		Socket skt=ss.accept();

		OutputStream os=skt.getOutputStream();
		InputStream is=skt.getInputStream();
		byte b[];
		String data;
BufferedReader br=new BufferedReader( new InputStreamReader(System.in));

		while(true)
		{
			b=new byte[1000];
			is.read(b);
			data=new String(b);
			data=data.trim();
			System.out.println("CLIENT :>" +data);

			System.out.print("SERVER:>");
			data=br.readLine();
			os.write( data.getBytes() );


		}


	}
}