import java.net.*;
import java.io.*;

class MySkt1
{
	public static void main(String a[]) throws Exception
	{
		Socket skt=new Socket("localhost",12325);
		InputStream is=skt.getInputStream();
		OutputStream os=skt.getOutputStream();
		byte b[];
		String data;
BufferedReader br=new BufferedReader( new InputStreamReader(System.in));

		while(true)
		{
			System.out.print("CLIENT:>");
			data=br.readLine();
			os.write( data.getBytes() );

			b=new byte[1000];
			is.read(b);
			data=new String(b);
			data=data.trim();
			System.out.println("SERVER :>" +data);

		}



	}
}