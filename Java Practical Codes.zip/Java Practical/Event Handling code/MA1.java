import java.awt.*;
import java.awt.event.*;

class MA1 extends Frame implements ActionListener, MouseListener
{
	Button b;
	MA1()
	{
		setSize(400,300);
		setLocation(300,100);
		setLayout(new FlowLayout());
		b=new Button("                CLICK  ME                   ");
		add(b);

		b.addActionListener( this );

		b.addMouseListener(this);

		setVisible(true);
	}

	public static void main(String a[])
	{
		new MA1();
	}

	public void actionPerformed(ActionEvent e)
	{
		System.out.println("hello hi");
	}

	public void mouseEntered(MouseEvent e)
	{
		b.setLabel("   DON'T CLICK NOW    ");
	}
	public void mouseExited(MouseEvent e)
	{
		b.setLabel("         CLICK ME         ");
	}
	public void mousePressed(MouseEvent e)
	{}
	public void mouseReleased(MouseEvent e)
	{}
	public void mouseClicked(MouseEvent e)
	{
		System.out.println("CLICKED");
	}


}

class A1 implements ActionListener
{
	public void actionPerformed(ActionEvent e)
	{
		System.out.println("hi");
	}
}

class A2 implements ActionListener
{
	public void actionPerformed(ActionEvent e)
	{
		System.out.println("hllo");
	}
}