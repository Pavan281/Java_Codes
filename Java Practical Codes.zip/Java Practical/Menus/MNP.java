import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MNP extends Frame implements ActionListener
{
	MenuBar mb;
	Menu fil;
	MenuItem ne,op,sv,sa,xi;
	TextArea ta;
	public MNP()
	{
		setSize(800,500);
		mb=new MenuBar();
		fil=new Menu("FILE");
		ne=new MenuItem("New");	
		op=new MenuItem("Open");	
		sv=new MenuItem("Save");	
		sa=new MenuItem("Save As");	
		xi=new MenuItem("Exit");	
		ta=new TextArea();

		setMenuBar(mb);
		mb.add(fil);
		fil.add(ne);
		fil.add(op);
		fil.addSeparator();
		fil.add(sv);
		fil.add(sa);
		fil.addSeparator();
		fil.add(xi);

		add(ta);

		ta.setFont(new Font("arial",Font.PLAIN,26));

		ne.addActionListener(this);
		op.addActionListener(this);
		sv.addActionListener(this);
		sa.addActionListener(this);
		xi.addActionListener(this);
		setVisible(true);
	}

	public static void main(String a[])
	{
		new MNP();
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==xi)
		{
			System.exit(0);
		}

		if(e.getSource()==ne)
		{
			ta.setText("");
		}
		if(e.getSource()==sa)
		{
			try{
		FileDialog fd=new FileDialog(new Frame(),"",FileDialog.SAVE);
		fd.setVisible(true);
		String fn=fd.getDirectory()+fd.getFile();
		FileOutputStream fout=new FileOutputStream(fn);
		String data=ta.getText();
		fout.write(data.getBytes());
		fout.close();
			}catch(Exception e1){}						
		}

		if(e.getSource()==op)
		{
			try{
		FileDialog fd=new FileDialog(new Frame(),"",FileDialog.LOAD);
		fd.setVisible(true);
		String fn=fd.getDirectory()+fd.getFile();
		FileInputStream fin=new FileInputStream(fn);
		byte b[]=new byte[ fin.available()];
		fin.read(b);
		ta.setText( new String(b));
		fin.close();
			}catch(Exception e1){}						
		}

	}
}