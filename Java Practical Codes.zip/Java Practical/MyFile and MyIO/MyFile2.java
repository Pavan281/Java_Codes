import java.io.*;

class MyFile2
{
	public static void main(String a[]) throws Exception
	{
		String s="HELLO";

	FileWriter fout=new FileWriter("d:/java6/ATEST1.txt");
	fout.write( s );
	fout.close();
	}
}
/*
	in MyFile1.java, we used FileOutputStream to write data and we have written the byte[] ... s.getBytes().....

as the FILE is on harddisk, and it is a HW component, so we used LLS, which writes data byte by byte (i.e. one byte at a time).....

but in this program, we are using FileWriter..... which is a HLS, (char stream), and actually it has to write 2 bytes data at a time. 
	but, this FileWriter is not writing data to another SW progeram. but it is used to write data to a FILE on HD, i.e. the code has HW interactivity. but whereever we have HW interactivity , the HL streams can not do writing/reading.

	but in later versions of JDK1.6, this facility is provided to read / write data using HLS. 

	but the HLS wont access HW component directly...........
when we use FileWriter to write data, the FileWriter WRAPS the class FileOutputStream and when we call write(str), it inturn calls write(str.getBytes() ) of FileOutputStream and data written to HD. 


	the FileReader / FileWriter can be used for text files. but these wont work for binary files. so the binary files must be accessed with FileInputStream / FileOutputStream ONLY. 
*/