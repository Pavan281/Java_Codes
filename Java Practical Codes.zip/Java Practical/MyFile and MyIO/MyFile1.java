import java.io.*;

class MyFile1
{
	public static void main(String a[]) throws Exception
	{
		String s="HELLO";

	FileOutputStream fout=new FileOutputStream("d:/java6/ATEST.txt");
	fout.write( s.getBytes() );
	fout.close();

	}
}