import java.io.*;

class MyIO1 
{
	public static void main(String a[]) throws IOException
	{
BufferedReader br=new BufferedReader( new InputStreamReader(System.in) );
System.out.println("Enter name");
String name=br.readLine();
System.out.println("name is " + name);

	}
}