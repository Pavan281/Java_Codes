import java.io.*;

class MyFile3
{
	public static void main(String a[]) throws Exception
	{
	FileInputStream fin=new FileInputStream("d:/java6/streams.txt");
	byte b[]=new byte[ fin.available()  ];
	fin.read(b);
	System.out.println( new String(b) );

	fin.close();

	}
}