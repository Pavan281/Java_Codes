import java.io.*;

class MyIO2
{
	public static void main(String aa[]) throws IOException
	{
BufferedReader br=new BufferedReader( new InputStreamReader(System.in) );
System.out.println("Enter 2 numbers");
int a = Integer.parseInt(br.readLine());
int b = Integer.parseInt(br.readLine());
int c=a/b;
System.out.println("result " + c);
	}
}